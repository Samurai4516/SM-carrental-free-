Config = {}


--bikes
Config.bike1 = 'surron' -- bike 1
Config.bike2 = 'sanchez' -- bike 2
Config.bike3 = 'sanchez' -- bike 3D

--offroad
Config.offroad1 = 'surron' -- offroad 1
Config.offroad2 = 'panto' -- offroad2
Config.offroad3 = 'sanchez' -- offroad3

--cars
Config.car1 = 'panto' -- car 1
Config.car2 = 'panto' -- car 2
Config.car3 = 'panto' -- car 3

--cash
Config.amount = 1
Config.account = 'money' -- take money from bank or cash?

-- ped related
Config.pedCoords = { x = -1590.3033, y = -1058.4667, z = 11.99174, h = 327.0593 } -- ped coords
Config.ped = 'ig_orleans' -- ped model get from here https://docs.fivem.net/docs/game-references/ped-models/
Config.oxtarget = { x = -1590.3920, y = -1058.5338, z = 13.0174, h = 327.0593} -- ox target coords



--- locales change the text in "" to ur langauge.
Config.Locales = {
    ["rent_vehicle"] = "Rent Vehicle"
}